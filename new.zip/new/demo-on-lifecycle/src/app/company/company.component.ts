import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit,OnChanges,DoCheck,AfterContentInit,AfterContentChecked,AfterViewInit,AfterViewChecked
,OnDestroy{

  constructor() {
    console.log("we are in constructor")
   }
  ngOnDestroy(): void {
    console.log("we are in ngOnDestroy")
  }
  ngAfterViewChecked(): void {
    console.log("we are in ngAfterViewChecked")
  }
  ngAfterViewInit(): void {
    console.log("we are in ngAfterViewInit")
  }
  ngAfterContentChecked(): void {
    console.log("we are in ngAfterContentChecked")
  }
  ngAfterContentInit(): void {
    console.log(" we are in ngAfterContentInit")
  }
  ngDoCheck(): void {
    console.log(" we are in ngDoCheck")

  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log(" we are in ngOnChanges")
  }

  @Input() companyName:string="";

  ngOnInit(): void {
    console.log(" we are in ngInit")
  }
  display(){
    console.log("we are in display method")
  }

}
