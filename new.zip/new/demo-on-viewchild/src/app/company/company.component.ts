import { Component, OnInit, ViewChild } from '@angular/core';
import { EmployeeComponent } from '../employee/employee.component';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  compantName: string = "XYZ Company";
  accessempNameFromEc: string = ""
  displayName:string="";
  @ViewChild(EmployeeComponent) ecobj = new EmployeeComponent(); //creating obj from child component and 
                                                                 //access prop and methods from childcomponent
  onClickMeClicked() {
    this.accessempNameFromEc = this.ecobj.empName;
    console.log(this.ecobj);
    console.log(this.ecobj.display())
    this.displayName=this.ecobj.display();
  }

}

