import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name:"mysqrt"
})
export class ExampleOnCustomPipe implements PipeTransform{

transform(num:number):number {
    
    return Math.sqrt(num);

}

}
