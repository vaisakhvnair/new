import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ExampleOnCustomPipe } from './ExampleOnCustomPipe';
import { DurationPipe } from './duration.pipe';

@NgModule({
  declarations: [
    AppComponent,
    ExampleOnCustomPipe,
    DurationPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
