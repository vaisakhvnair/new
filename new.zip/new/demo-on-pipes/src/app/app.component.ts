import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo-on-pipes';

  city:string="Trivandrum";
  salary:number=450000;
  n:number=0.75;
  person:Object={"firstName":"vaisakh","lastName":"V"};
  dt:Date=new Date
  videoDuration:number=150
}
